<?php
require 'db.php';
$result = $mysqli->query("SELECT matric,name,accessLevel FROM users");
?>
<!DOCTYPE html><html><head><title>User List</title></head><body>
<h2>User List</h2>
<table border="1" cellpadding="8">
<tr><th>Matric</th><th>Name</th><th>Access Level</th><th>Action</th></tr>
<?php while($u=$result->fetch_assoc()): ?>
<tr>
<td><?= $u['matric'] ?></td>
<td><?= $u['name'] ?></td>
<td><?= $u['accessLevel'] ?></td>
<td>
<a href="update.php?matric=<?= $u['matric'] ?>">Update</a> |
<a href="delete.php?matric=<?= $u['matric'] ?>" onclick="return confirm('Delete user?')">Delete</a>
</td>
</tr>
<?php endwhile; ?>
</table>
</body></html>