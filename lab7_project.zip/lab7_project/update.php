<?php
require 'db.php';
$matric = $_GET['matric'];
$q = $mysqli->query("SELECT * FROM users WHERE matric='$matric'");
$u = $q->fetch_assoc();
?>
<!DOCTYPE html><html><head><title>Update User</title></head><body>
<h2>Update User</h2>
<form action="update_process.php" method="POST">

<input type="hidden" name="original_matric" value="<?= $u['matric'] ?>">

Matric:<br>
<input name="matric" value="<?= $u['matric'] ?>" required><br><br>

Name:<br>
<input name="name" value="<?= $u['name'] ?>" required><br><br>

Access Level:<br>
<select name="accessLevel">
<option value="student" <?= $u['accessLevel']=="student"?"selected":"" ?>>Student</option>
<option value="lecturer" <?= $u['accessLevel']=="lecturer"?"selected":"" ?>>Lecturer</option>
</select><br><br>

<button>Save</button>
</form>
</body></html>