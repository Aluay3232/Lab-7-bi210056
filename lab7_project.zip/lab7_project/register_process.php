<?php
require 'db.php';
$mat=$_POST['matric']; $n=$_POST['name']; $e=$_POST['email'];
$p=password_hash($_POST['password'], PASSWORD_DEFAULT);
$a=$_POST['accessLevel'];
$stmt=$mysqli->prepare("INSERT INTO users VALUES (?,?,?,?,?)");
$stmt->bind_param("sssss",$mat,$n,$e,$p,$a);
if($stmt->execute()) echo "Registered <a href='login.php'>Login</a>";
else echo "Error ".$mysqli->error;
?>