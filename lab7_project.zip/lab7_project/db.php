<?php
$mysqli = new mysqli("localhost","root","","Lab_7");
if ($mysqli->connect_errno) { die("DB connection error"); }
?>