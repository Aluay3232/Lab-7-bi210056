<?php
require 'db.php';
$m = $_GET['matric'];
$mysqli->query("DELETE FROM users WHERE matric='$m'");
header("Location: display.php");
?>