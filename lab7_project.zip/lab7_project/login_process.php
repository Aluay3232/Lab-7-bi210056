<?php
session_start();
require 'db.php';

$email    = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Prepare and run query
$stmt = $mysqli->prepare("SELECT matric, password, name, accessLevel FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 1) {
    $stmt->bind_result($matric, $dbPassword, $name, $accessLevel);
    $stmt->fetch();

    // NOW we use password_verify because password in DB is hashed
    if (password_verify($password, $dbPassword)) {
        $_SESSION['matric']      = $matric;
        $_SESSION['name']        = $name;
        $_SESSION['accessLevel'] = $accessLevel;

        header("Location: display.php");
        exit();
    }
}

// If we reach here, login failed
echo "Invalid login. <a href='login.php'>Retry</a>";
?>
