<?php
require 'db.php';

$original = $_POST['original_matric'];
$matric   = $_POST['matric'];
$name     = $_POST['name'];
$access   = $_POST['accessLevel'];

$mysqli->query("UPDATE users SET matric='$matric', name='$name', accessLevel='$access' WHERE matric='$original'");

header("Location: display.php");
exit;
?>