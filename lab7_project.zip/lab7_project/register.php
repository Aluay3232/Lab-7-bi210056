<!DOCTYPE html>
<html><head><title>Register</title><link rel="stylesheet" href="styles.css"></head>
<body><h2>Register</h2>
<form action="register_process.php" method="POST">
Matric:<br><input name="matric" required><br><br>
Name:<br><input name="name" required><br><br>
Email:<br><input name="email" required><br><br>
Password:<br><input type="password" name="password" required><br><br>
Access Level:<br>
<select name="accessLevel">
<option value="student">Student</option>
<option value="lecturer">Lecturer</option>
</select><br><br>
<button>Register</button>
</form>
<a href="login.php">Login</a>
</body></html>